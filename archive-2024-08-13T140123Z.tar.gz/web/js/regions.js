componentconstructors['regions'] = function(dynmap, configuration) {

}